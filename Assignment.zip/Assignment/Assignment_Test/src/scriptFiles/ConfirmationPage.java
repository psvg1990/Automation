package scriptFiles;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class ConfirmationPage {


	@FindBy(xpath="//tr//td[text()='Id']//..//td[2]")
	private WebElement Id;


	@FindBy(xpath="//tr//td[text()='Auth Code']//..//td[2]")
	private WebElement AuthinticationCode;




	public ConfirmationPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	public void flightConfirmation()
	{
		try {

			if(Id.isDisplayed() && AuthinticationCode.isDisplayed())
			{
				System.out.println("FlightTicket is confirmed");
			}
		}
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
}

