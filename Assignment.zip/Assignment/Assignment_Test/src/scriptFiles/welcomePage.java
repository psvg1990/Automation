package scriptFiles;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import baseClassFiles.baseClass;



public class welcomePage  extends baseClass
{

	/*
	@FindBy(xpath="//select [@name='fromPort']")
	private WebElement DepartureCity;



	@FindBy(xpath="//select [@name='toPort']")
	private WebElement DestinationCity;


	@FindBy(xpath="//input[@value='Find Flights']")
	private WebElement FindFlights;

	public welcomePage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	 */
	


	public WebElement DepartureCity=driver.findElement(By.xpath("//select [@name='fromPort']"));
	public WebElement DestinationCity =driver.findElement(By.xpath("//select [@name='toPort']"));
	public WebElement FindFlights =driver.findElement(By.xpath("//input[@value='Find Flights']"));
	
	


	public welcomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}



	public void submitFindFlights() 
	{
		try {
			Thread.sleep(3000);
			
			Select select1=new Select(DepartureCity);
			select1.selectByVisibleText("Paris");
			Thread.sleep(2000);
			Select select2=new Select(DestinationCity);
			select2.selectByVisibleText("London");

			FindFlights.click();
			
		} catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}


}
