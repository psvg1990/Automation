package scriptFiles;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

public class PurchaseFlightTicket {

	@FindBy(xpath="(//div)[4]//p[text()='Airline: United']")
	private WebElement AirlineName;

	@FindBy(xpath="(//div)[4]//p[text()='Flight Number: UA954']")
	private WebElement FlightNumber;

	@FindBy(xpath="//div//input[@name='inputName']")
	private WebElement Name;


	@FindBy(xpath="//div//input[@name='address']")
	private WebElement Address;


	@FindBy(xpath="//div//input[@name='city']")
	private WebElement City;


	@FindBy(xpath="//div//input[@name='state']")
	private WebElement state;


	@FindBy(xpath="//div//input[@name='zipCode']")
	private WebElement Zipcode;


	@FindBy(xpath="//div//select[@name='cardType']")
	private WebElement Visa;

	@FindBy(xpath="//div//input[@name='creditCardNumber']")
	private WebElement CreditCardNumber;


	@FindBy(xpath="//div//input[@name='nameOnCard']")
	private WebElement NameOnCard;


	@FindBy(xpath="//div//input[@value='Purchase Flight']")
	private WebElement PurchaseFlight;





	public PurchaseFlightTicket(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	public void purchaseFlight()
	{

		try {
			SoftAssert softAssert = new SoftAssert();

			String Airlinename=AirlineName.getText();

			softAssert.assertEquals(Airlinename, "Airline: United");

			Name.sendKeys("JobOppournist");
			Address.sendKeys("Krishnarajapura");
			City.sendKeys("Bengaluru");
			state.sendKeys("Karnataka");
			Zipcode.sendKeys("560001");

			Select select=new Select(Visa);
			select.selectByVisibleText("American Express");

			CreditCardNumber.sendKeys("4356 1234 6543 9087");

			NameOnCard.sendKeys("Johnsmith");

			PurchaseFlight.click();
		}


		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




	}

}
