package scriptFiles;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baseClassFiles.baseClass;

public class SelectFlightPage extends baseClass
{

	public WebElement ChooseFlight =driver.findElement(By.xpath("//select [@name='fromPort']"));
	public WebElement DestinationCity =driver.findElement(By.xpath("//select [@name='toPort']"));
	public WebElement FindFlights =driver.findElement(By.xpath("//input[@value='Find Flights']"));
	

}
