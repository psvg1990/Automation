package executableFiles;
import scriptFiles.ConfirmationPage;
import scriptFiles.PurchaseFlightTicket;
import scriptFiles.SelectFlightPage;
import scriptFiles.welcomePage;

import org.testng.annotations.Test;

import baseClassFiles.baseClass;
import scriptFiles.*;




public class welcomePageExecute extends baseClass
{
	@Test
	public static void main(String args[]) throws InterruptedException
	{

		welcomePage page1=new welcomePage(driver);
		SelectFlightPage page2= new SelectFlightPage(driver);
		PurchaseFlightTicket page3=new PurchaseFlightTicket(driver);
		ConfirmationPage page4= new ConfirmationPage(driver);

		Thread.sleep(3000);
		page1.submitFindFlights();


		Thread.sleep(3000);
		
		page2.chooseFlight();

		Thread.sleep(3000);
		page3.purchaseFlight();

		Thread.sleep(3000);
		page4.flightConfirmation();

	}

}
